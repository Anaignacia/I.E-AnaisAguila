#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Sat Apr 20 12:58:59 2023

@author: anais
"""

print("División entre dos numeros (A) y (B)")
print("Seleccione un numero")
A= int(input())

print("Seleccione otro numero")
B= int(input())

resto = A%B  #calcula el resto de la división, si es 0 es exacta

if resto == 0:  
    print("La división es exacta")
    
else: # si no cumple con el caso de arriba, entonces no es exacta
    print("La división no es exacta")