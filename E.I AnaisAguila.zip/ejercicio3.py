#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Sat Apr 21 13:08:04 2023

@author: anais
"""
# variables y listas
print("Comprobador de fechas")

print(" escoja un dia")
dias = int(input())
print(" escoja un mes")
mes = int(input())
print("escoja un año")
año = int(input())
# suma los dias desde el mes anterior hacia atras
meses = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31] 
bis = 0 

# revisa si la fecha existe
while dias < 1 or dias >= 32:
    print("escoja un dia valido")
    dias = int(input())

while mes < 1 or mes > 12:
    print("escoja un mes válido")
    mes = int(input())


# Calcula si el año es bisiesto 
if año % 4 == 0 and año % 100 == 0 and año % 400 == 0: # si se cumplen todas las condiciónes
    bis = 1 # el año si es bisiesto
if año % 4 == 0 and año % 100 != 0 and año % 400 != 0:
    bis = 1  

suma_meses = 0 # es la suma de los dias de los meses
bucle = mes - 2 
while 0 <= bucle: # suma en bucle mes por mes, hasta que llega a enero
    suma_meses = suma_meses + meses[bucle]
    bucle = bucle - 1

# parte 2 y 3 de la tarea

totalaño = suma_meses + dias + bis # parte 2

natal = 0 #parte 3


if (suma_meses + dias) > 4: # si falta para el cumpleaños, y es en el siguiente año
    natal = 4 + 365 - totalaño
    if mes >= 3: 
        natal = natal + bis 

if (suma_meses + dias) <= 4: # si falta para el cumpleaños, en el mismo año.
    natal = 4 - totalaño


# final :

if bis == 0:  #parte 1
    print("El año escogido no es bisiesto")

if bis == 1: #parte 1
    print("El año escogido es bisiesto")
    
    # parte 2
    
print("han pasado ", totalaño, "dias desde el inicio del año de la fecha escogida.")

    # parte 3

print("en", natal, "días es el natalicio de Isaac Newton, según la fecha escogida")