#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Apr 19 20:02:47 2023

@author: anais
"""

print("Calcudor de promedio")
print("Ingrese la cantidad de notas que desea promediar: ")

N_notas = int(input()) #numero de notas

Bucle = 1 # Bucle es la cantidad que se le suma al conteo 
Sumas = 0 

while Bucle <= N_notas:
    print("Ponga su nota numero ", Bucle, ":")
    Sumas=(Sumas + float(input())) # Copia N_notas y suma la siguiente 
    Bucle = Bucle + 1              # Suma uno al conteo
    
Promedio = (Sumas/N_notas) 

print("Tu  promedio actual es ", Promedio)

#Aquì te indica el promedio y si estas aprobando o no.

if Bucle >= 4.0:
    print("Felicitaciones, vas camino a aprobar.")
    
elif Bucle >= 3.0 and Bucle <4.0:
    print("Atenciòn, vas camino a reprobar")
 
elif Bucle < 3.0:
     print("Pocas probabilidades de aprobar")
